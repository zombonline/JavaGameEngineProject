<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Tiles" tilewidth="512" tileheight="512" tilecount="6" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../Images/Crates/crate_hover.png" width="512" height="512"/>
 </tile>
 <tile id="1">
  <image source="../Images/Crates/crate_basic.png" width="512" height="512"/>
 </tile>
 <tile id="2">
  <image source="../Images/Crates/crate_bounce.png" width="512" height="512"/>
 </tile>
 <tile id="3">
  <image source="../Images/Crates/crate_explosive.png" width="512" height="512"/>
 </tile>
 <tile id="4">
  <image source="../Images/Crates/crate_metal.png" width="512" height="512"/>
 </tile>
 <tile id="9">
  <image source="../Images/Crates/crate_background.png" width="512" height="512"/>
 </tile>
</tileset>
